package com.example.course_system.service;


import java.util.List;

public interface Services<T> {

    T getById(int id);
    List<T> get();
    String update(T t);
    String save(T t);
    String deleteById(int id);

}
