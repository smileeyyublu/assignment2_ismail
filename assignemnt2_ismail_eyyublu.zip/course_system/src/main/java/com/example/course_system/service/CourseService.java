package com.example.course_system.service;

import com.example.course_system.entity.Course;
import com.example.course_system.repository.CourseRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService implements Services<Course> {

    private final CourseRepo courseRepo;

    @Autowired
    public CourseService(CourseRepo courseRepo) {
        this.courseRepo = courseRepo;
    }

    @Override
    public Course getById(int id) {
        return courseRepo.getById(id);
    }

    @Override
    public List<Course> get() {
        return courseRepo.findAll();
    }

    @Override
    public String update(Course course) {
        courseRepo.save(course);
        return "Updated";
    }

    @Override
    public String save(Course course) {
        courseRepo.save(course);
        return "Saved";
    }

    @Override
    public String deleteById(int id) {
        courseRepo.deleteById(id);

        return "Deleted";
    }
}
