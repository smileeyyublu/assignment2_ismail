package com.example.course_system.controller;

import com.example.course_system.entity.Teacher;
import com.example.course_system.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class TeacherController {

    private final TeacherService teacherService;

    @Autowired
    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @GetMapping("/teacher")
    public List<Teacher> getTeacher(){
        return teacherService.get();
    }

    @GetMapping("/teacher/{id}")
    public String getTeacherById(@PathVariable int id){
        if(teacherService.getById(id)==null)
            return String.valueOf(new NullPointerException("There is no teacher!"));
        return String.valueOf(teacherService.getById(id));
    }

    @PostMapping("/teacher")
    public String createTeacher(@RequestBody Teacher teacher){
        teacherService.save(teacher);
        return "Saved successfully!"+teacher.toString();
    }

    @PutMapping("/teacher")
    public String updateTeacher(@RequestBody Teacher teacher){
        teacherService.update(teacher);
        return "Teacher is updated!"+teacher.toString();
    }

    @DeleteMapping("/teacher/{id}")
    public String deleteTeacher(@PathVariable int id){
        if(teacherService.getById(id)==null)
            return String.valueOf(new NullPointerException("This id not found "+id));
        else teacherService.deleteById(id);
        return "Deleted Successfully!..";
    }

}
