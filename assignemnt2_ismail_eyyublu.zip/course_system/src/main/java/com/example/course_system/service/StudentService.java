package com.example.course_system.service;

import com.example.course_system.entity.Student;
import com.example.course_system.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService implements Services<Student> {

    private final StudentRepo studentRepo;

    @Autowired
    public StudentService(StudentRepo studentRepo) {
        this.studentRepo = studentRepo;
    }

    @Override
    public Student getById(int id) {
        return studentRepo.getById(id);
    }

    @Override
    public List<Student> get() {
        return studentRepo.findAll();
    }

    @Override
    public String update(Student student) {
        studentRepo.save(student);
        return "Updated";
    }

    @Override
    public String save(Student student) {
        studentRepo.save(student);
        return "Saved";
    }

    @Override
    public String deleteById(int id) {
        studentRepo.deleteById(id);
        return "Deleted";
    }
}
