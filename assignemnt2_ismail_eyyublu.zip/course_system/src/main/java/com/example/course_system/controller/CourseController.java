package com.example.course_system.controller;

import com.example.course_system.entity.Course;
import com.example.course_system.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CourseController {

    private final CourseService courseService;

    @Autowired
    public CourseController(CourseService courseController) {
        this.courseService = courseController;
    }

    @GetMapping("/course")
    public List<Course> getCourse(){
        return courseService.get();
    }

    @GetMapping("/course/{id}")
    public String getCourseById(@PathVariable int id){
        if(courseService.getById(id)==null)
            return String.valueOf(new NullPointerException("There is no course!"));
        return String.valueOf(courseService.getById(id));
    }

    @PostMapping("/course")
    public String createCourse(@RequestBody Course course){
        courseService.save(course);
        return "Saved successfully!"+course.toString();
    }

    @PutMapping("/course")
    public String updateCourse(@RequestBody Course course){
        courseService.update(course);
        return "Course is updated!"+course.toString();
    }


    @DeleteMapping("/course/{id}")
    public String deleteCourse(@PathVariable int id){
        if(courseService.getById(id)==null)
            return String.valueOf(new NullPointerException("This id not found "+id));
        else courseService.deleteById(id);
        return "Deleted Successfully!..";
    }

}
