package com.example.course_system.controller;

import com.example.course_system.entity.Student;
import com.example.course_system.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {

    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/student")
    public List<Student> getStudent(){
        return studentService.get();
    }

    @GetMapping("/student/{id}")
    public String getStudentById(@PathVariable int id){
        if(studentService.getById(id)==null)
            return String.valueOf(new NullPointerException("There is no student!"));
        return String.valueOf(studentService.getById(id));
    }

    @PostMapping("/student")
    public String createStudent(@RequestBody Student student){
        studentService.save(student);
        return "Saved successfully!"+student.toString();
    }

    @PutMapping("/student")
    public String updateStudent(@RequestBody Student student){
        studentService.update(student);
        return "Student is updated!"+student.toString();
    }

    @DeleteMapping("/student/{id}")
    public String deleteStudent(@PathVariable int id){
        if(studentService.getById(id)==null)
            return String.valueOf(new NullPointerException("This id not found "+id));
        else studentService.deleteById(id);
        return "Deleted Successfully!..";
    }

}
