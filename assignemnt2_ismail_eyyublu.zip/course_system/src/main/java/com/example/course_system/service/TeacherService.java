package com.example.course_system.service;

import com.example.course_system.entity.Teacher;
import com.example.course_system.repository.TeacherRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService implements Services<Teacher> {

    private final TeacherRepo teacherRepo;

    @Autowired
    public TeacherService(TeacherRepo teacherRepo) {
        this.teacherRepo = teacherRepo;
    }

    @Override
    public Teacher getById(int id) {
        return teacherRepo.getTeacherById(id);
    }

    @Override
    public List<Teacher> get() {
        return teacherRepo.findAll();
    }

    @Override
    public String update(Teacher teacher) {
        teacherRepo.save(teacher);
        return "Updated";
    }

    @Override
    public String save(Teacher teacher) {
        teacherRepo.save(teacher);
        return "Saved";
    }

    @Override
    public String deleteById(int id) {
        teacherRepo.deleteById(id);
        return "Deleted";
    }
}
