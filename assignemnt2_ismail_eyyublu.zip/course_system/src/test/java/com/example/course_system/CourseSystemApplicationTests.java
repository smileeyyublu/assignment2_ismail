package com.example.course_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
